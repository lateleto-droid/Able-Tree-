import { Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-[#1B4D3E] rounded-lg flex items-center justify-center">
                <span className="text-white font-heading font-bold text-xl">A</span>
              </div>
              <span className="font-heading font-bold text-2xl text-white tracking-tight">
                Able Tree Service
              </span>
            </div>
            <p className="text-sm leading-relaxed text-gray-400">
              Professional, safe, and reliable tree services in Edison, NJ. Fully licensed and insured for your peace of mind.
            </p>
            <div className="flex gap-4">
              {/* Social placeholders */}
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#1B4D3E] transition-colors">
                <span className="sr-only">Facebook</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" /></svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold font-heading mb-6 uppercase tracking-wider text-sm">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="hover:text-white transition-colors">Our Services</a></li>
              <li><a href="#before-after" className="hover:text-white transition-colors">Before & After</a></li>
              <li><a href="#reviews" className="hover:text-white transition-colors">Customer Reviews</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact & Quote</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold font-heading mb-6 uppercase tracking-wider text-sm">Our Services</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="hover:text-white transition-colors">Tree Removal</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Tree Trimming</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Emergency Services</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Stump Grinding</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Property Clearing</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold font-heading mb-6 uppercase tracking-wider text-sm">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#1B4D3E] flex-shrink-0 mt-0.5" />
                <span>961 Amboy Ave<br />Edison, NJ 08837</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#1B4D3E] flex-shrink-0" />
                <a href="tel:7326610433" className="hover:text-white transition-colors">(732) 661-0433</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#1B4D3E] flex-shrink-0" />
                <a href="mailto:info@abletreeservicenj.com" className="hover:text-white transition-colors">info@abletreeservicenj.com</a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            &copy; {currentYear} Able Tree Service. All rights reserved.
          </p>
          <div className="text-sm text-gray-500 flex gap-4">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
