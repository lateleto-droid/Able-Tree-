'use client';

import { useState, useEffect } from 'react';
import { Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function FloatingCall() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show button after scrolling down 300px
      setIsVisible(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.8 }}
          className="fixed bottom-6 right-6 z-50 md:hidden"
        >
          <a
            href="tel:7326610433"
            className="flex items-center justify-center w-14 h-14 bg-[#1B4D3E] text-white rounded-full shadow-[0_4px_20px_rgba(27,77,62,0.5)] hover:bg-[#12362b] transition-colors relative group"
          >
            {/* Pulse effect */}
            <span className="absolute inset-0 rounded-full bg-[#1B4D3E] animate-ping opacity-20"></span>
            <Phone className="w-6 h-6 relative z-10" />
            <span className="sr-only">Call Now</span>
          </a>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
