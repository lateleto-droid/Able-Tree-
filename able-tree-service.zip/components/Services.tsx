'use client';

import { motion } from 'motion/react';
import { Scissors, AlertTriangle, TreePine, Axe, Tractor } from 'lucide-react';

const services = [
  {
    title: 'Tree Removal',
    description: 'Safe and efficient tree removal near you. We handle large, dead, or hazardous trees in tight spaces with professional equipment.',
    icon: Axe,
    image: 'https://picsum.photos/seed/tree-removal/600/400'
  },
  {
    title: 'Tree Trimming & Pruning',
    description: 'Expert tree trimming in Edison, NJ to promote healthy growth, improve aesthetics, and remove dangerous overhanging branches.',
    icon: Scissors,
    image: 'https://picsum.photos/seed/tree-trimming/600/400'
  },
  {
    title: 'Emergency Tree Services',
    description: '24/7 emergency tree service in NJ for storm damage. Fast response to safely remove fallen trees from homes, cars, or power lines.',
    icon: AlertTriangle,
    image: 'https://picsum.photos/seed/emergency-tree/600/400'
  },
  {
    title: 'Stump Grinding',
    description: 'Complete stump grinding and removal services to clear your yard, prevent pests, and prepare for new landscaping.',
    icon: TreePine,
    image: 'https://picsum.photos/seed/stump-grinding/600/400'
  },
  {
    title: 'Property Clearing',
    description: 'Thorough lot and property clearing for new construction, landscaping projects, or overgrown areas.',
    icon: Tractor,
    image: 'https://picsum.photos/seed/property-clearing/600/400'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-4"
          >
            Comprehensive Tree Services in Edison, NJ
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-gray-600"
          >
            From routine maintenance to complex removals, our experienced crew is equipped to handle all your tree care needs safely and affordably.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-300 group border border-gray-100"
            >
              <div className="relative h-48 overflow-hidden">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-300 z-10" />
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute bottom-0 left-0 p-4 z-20">
                  <div className="bg-white p-3 rounded-xl shadow-lg inline-block transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                    <service.icon className="w-6 h-6 text-[#1B4D3E]" />
                  </div>
                </div>
              </div>
              <div className="p-6 pt-8">
                <h3 className="text-xl font-bold text-gray-900 mb-3 font-heading group-hover:text-[#1B4D3E] transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
