'use client';

import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';
import Image from 'next/image';

export default function About() {
  const benefits = [
    "20+ Years of Experience",
    "Fully Licensed & Insured",
    "Family Owned & Operated",
    "State-of-the-Art Equipment",
    "Clean & Safe Work Sites",
    "Free, No-Obligation Estimates"
  ];

  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Image Side */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="https://picsum.photos/seed/about-tree-service/800/1000"
                alt="Able Tree Service Crew"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
                  <p className="text-3xl font-bold text-[#1B4D3E] font-heading mb-1">20+</p>
                  <p className="text-gray-800 font-medium">Years Serving Edison, NJ</p>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-green-100 rounded-full -z-10" />
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gray-100 rounded-full -z-10" />
          </motion.div>

          {/* Content Side */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-full lg:w-1/2"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-6">
              Trusted Tree Experts in Edison, NJ
            </h2>
            <div className="space-y-4 text-lg text-gray-600 mb-8">
              <p>
                Able Tree Service has built a strong reputation for delivering safe, efficient, and high-quality tree services. Our experienced crew is known for professionalism, reliability, and attention to detail on every job — no matter the size.
              </p>
              <p>
                We understand that tree removal and maintenance can be stressful for homeowners. That's why we prioritize safety above all else, using the latest equipment and techniques to protect your property while getting the job done right.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-[#1B4D3E] flex-shrink-0" />
                  <span className="font-medium text-gray-800">{benefit}</span>
                </div>
              ))}
            </div>

            <a
              href="tel:7326610433"
              className="inline-flex items-center justify-center px-8 py-4 text-base font-bold rounded-md text-white bg-[#1B4D3E] hover:bg-[#12362b] transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
            >
              Call Us Today: (732) 661-0433
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
