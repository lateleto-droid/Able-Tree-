'use client';

import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Mail, AlertCircle } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-4"
          >
            Get Your Free Estimate
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-gray-600"
          >
            Ready to transform your property? Contact us today for a free, no-obligation quote. We respond quickly to all inquiries.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h3 className="text-2xl font-bold font-heading text-gray-900 mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#1B4D3E]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Phone (Call or Text)</p>
                    <a href="tel:7326610433" className="text-xl font-bold text-gray-900 hover:text-[#1B4D3E] transition-colors">
                      (732) 661-0433
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#1B4D3E]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Location</p>
                    <p className="text-lg font-medium text-gray-900">
                      961 Amboy Ave<br />
                      Edison, NJ 08837
                    </p>
                    <p className="text-sm text-gray-600 mt-1">Serving Edison, Woodbridge, Metuchen, Piscataway, and nearby areas.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-[#1B4D3E]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Hours</p>
                    <p className="text-lg font-bold text-gray-900">Open 24 Hours — 7 Days a Week</p>
                    <p className="text-sm text-gray-600 mt-1">(Holiday hours may vary)</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-4 bg-red-50 rounded-xl border border-red-100 flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-red-800">Need Emergency Service?</p>
                  <p className="text-red-700 text-sm mt-1">We offer 24/7 emergency response for storm damage and fallen trees. Call immediately for fastest service.</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-2xl font-bold font-heading text-gray-900 mb-6">Request a Quote</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input 
                  type="text" 
                  id="name" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1B4D3E] focus:border-[#1B4D3E] outline-none transition-colors"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input 
                  type="tel" 
                  id="phone" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1B4D3E] focus:border-[#1B4D3E] outline-none transition-colors"
                  placeholder="(732) 555-0123"
                />
              </div>

              <div>
                <label htmlFor="service" className="block text-sm font-medium text-gray-700 mb-2">Service Needed</label>
                <select 
                  id="service" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1B4D3E] focus:border-[#1B4D3E] outline-none transition-colors bg-white"
                >
                  <option value="">Select a service...</option>
                  <option value="removal">Tree Removal</option>
                  <option value="trimming">Tree Trimming & Pruning</option>
                  <option value="emergency">Emergency Service</option>
                  <option value="stump">Stump Grinding</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Message / Details</label>
                <textarea 
                  id="message" 
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1B4D3E] focus:border-[#1B4D3E] outline-none transition-colors resize-none"
                  placeholder="Please describe the job..."
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full py-4 px-6 bg-[#1B4D3E] hover:bg-[#12362b] text-white font-bold rounded-lg transition-colors duration-300 shadow-md hover:shadow-lg flex items-center justify-center gap-2"
              >
                <Mail className="w-5 h-5" />
                Send Request
              </button>
              <p className="text-xs text-center text-gray-500 mt-4">
                By submitting this form, you agree to be contacted regarding your inquiry.
              </p>
            </form>
          </motion.div>
        </div>

        {/* Map */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 rounded-2xl overflow-hidden shadow-sm border border-gray-200 h-[400px] relative"
        >
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3032.531070281691!2d-74.3314546846006!3d40.53093917935123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c3c861217f2597%3A0x861461b2e6974864!2s961%20Amboy%20Ave%2C%20Edison%2C%20NJ%2008837!5e0!3m2!1sen!2sus!4v1650000000000!5m2!1sen!2sus" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={false} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Able Tree Service Location"
            className="absolute inset-0"
          ></iframe>
        </motion.div>
      </div>
    </section>
  );
}
