'use client';

import { motion } from 'motion/react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    id: 1,
    text: "I've used John & his crew for over 20 years. Always professional, skilled, and friendly. They handled a massive tree removal perfectly. Highly recommend Able Tree Service!",
    author: "Sarah M.",
    location: "Edison, NJ"
  },
  {
    id: 2,
    text: "The team did an excellent job with the tree removal. Everything was handled quickly, safely, and professionally. Johnny was great to work with — very polite and thorough.",
    author: "Michael T.",
    location: "Woodbridge, NJ"
  },
  {
    id: 3,
    text: "Fast response when a storm knocked down a branch on our roof. They came out the same day and safely removed it without causing any further damage. Lifesavers!",
    author: "David L.",
    location: "Metuchen, NJ"
  },
  {
    id: 4,
    text: "Very affordable pricing compared to other quotes I got. The crew cleaned up the yard perfectly after grinding two large stumps. You couldn't even tell they were there.",
    author: "Jessica R.",
    location: "Piscataway, NJ"
  }
];

export default function Reviews() {
  const [emblaRef] = useEmblaCarousel({ loop: true, align: 'start' }, [Autoplay({ delay: 5000 })]);

  return (
    <section id="reviews" className="py-24 bg-[#1B4D3E] text-white overflow-hidden relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex justify-center gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
            ))}
          </div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-heading font-bold mb-4"
          >
            Trusted by Homeowners in Edison, NJ
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-green-100"
          >
            Don't just take our word for it. See what our satisfied customers have to say about our tree services.
          </motion.p>
        </div>

        <div className="overflow-hidden" ref={emblaRef}>
          <div className="flex -ml-4">
            {reviews.map((review) => (
              <div key={review.id} className="flex-[0_0_100%] min-w-0 md:flex-[0_0_50%] lg:flex-[0_0_33.333%] pl-4">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl h-full flex flex-col relative">
                  <Quote className="absolute top-6 right-6 w-10 h-10 text-white/10" />
                  <div className="flex gap-1 mb-6">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-lg leading-relaxed mb-8 flex-grow">
                    "{review.text}"
                  </p>
                  <div>
                    <p className="font-bold font-heading text-lg">{review.author}</p>
                    <p className="text-green-200 text-sm">{review.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
