import type { Metadata } from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-heading',
});

export const metadata: Metadata = {
  title: 'Able Tree Service | Expert Tree Removal & Trimming in Edison, NJ',
  description: 'Safe, reliable, and professional tree services in Edison, NJ. We offer tree removal, trimming, stump grinding, and 24/7 emergency services. Call (732) 661-0433 for a free estimate.',
  keywords: 'Tree service Edison NJ, Tree removal near me, Tree trimming Edison NJ, Emergency tree service NJ, Affordable tree removal Edison, stump grinding, property clearing',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable} scroll-smooth`}>
      <body className="font-sans text-gray-900 bg-white antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
